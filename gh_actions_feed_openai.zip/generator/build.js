import axios from 'axios';
import { XMLParser } from 'fast-xml-parser';
import * as cheerio from 'cheerio';
import fs from 'fs/promises';
import pLimit from 'p-limit';

const cfg = JSON.parse(await fs.readFile('generator/config.json','utf-8'));
const today = new Date().toISOString().slice(0,10);
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';

const wait = ms => new Promise(r => setTimeout(r, ms));

function canon(u){
  try{ const x=new URL(u); x.hash=''; ['utm_source','utm_medium','utm_campaign','utm_term','utm_content','gclid','fbclid'].forEach(p=>x.searchParams.delete(p)); return x.href; }
  catch{ return u; }
}

async function fetchText(url){
  const res = await axios.get(url, { timeout: 12000, maxRedirects: 3, headers: { 'user-agent': 'NVFetcher/1.0' } });
  return res.data;
}

function parseRSS(xml, section, label){
  const parser = new XMLParser({ ignoreAttributes: false });
  let j={}; try{ j = parser.parse(xml) } catch { return [] }
  const items = j?.rss?.channel?.item || j?.feed?.entry || [];
  const arr = Array.isArray(items) ? items : [items];
  return arr.map(it=>{
    const title = (it.title && (typeof it.title === 'object' ? it.title['#text'] : it.title)) || '';
    let link = it.link;
    if(typeof link === 'object'){ link = link['@_href'] || link['#text'] || '' }
    const desc = it.description || it.summary || '';
    const pub = it.pubDate || it.updated || it.published || null;
    return { title: String(title).trim(), url: String(link||'').trim(), summary: String(desc||'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim().slice(0,300), published_at: pub, section, source: label, image_url: null };
  }).filter(i=>i.url);
}

function parseHTMLList(html, baseUrl, section, label){
  const $ = cheerio.load(html);
  const out = [];
  $('a[href]').each((_,a)=>{
    const href = $(a).attr('href') || '';
    const text = $(a).text().replace(/\s+/g,' ').trim();
    if(!href || href.startsWith('#') || href.startsWith('mailto:')) return;
    if(!text || text.length < 6) return;
    const url = new URL(href, baseUrl).href;
    out.push({ title: text, url, summary: '', published_at: null, section, source: label, image_url: null });
  });
  const seen = new Set();
  return out.filter(x => seen.has(x.url) ? false : (seen.add(x.url), true)).slice(0, 60);
}

async function getOG(url){
  try{
    const html = await fetchText(url);
    const $ = cheerio.load(html);
    const c = $('meta[property="og:image"], meta[name="twitter:image"]').attr('content');
    return c || null;
  }catch{ return null; }
}

async function enhancePTBR(items){
  if(!OPENAI_API_KEY) return items;
  const limit = pLimit(3); // 3 chamadas concorrentes
  const model = 'gpt-4o-mini';
  async function callAI(it){
    try{
      const payload = {
        model,
        messages: [
          { role: 'system', content: 'Você é um editor jornalístico brasileiro. Reescreva títulos e resumos em PT-BR, claros, atraentes e informativos. Nada de clickbait. Título <= 90 caracteres. Resumo: 1-2 frases.' },
          { role: 'user', content: `Reescreva em PT-BR.\nFonte: ${it.source}\nTítulo: ${it.title}\nResumo: ${it.summary}\nURL: ${it.url}` }
        ],
        temperature: 0.4,
      };
      const r = await axios.post('https://api.openai.com/v1/chat/completions', payload, {
        headers: { 'Authorization': `Bearer ${OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
        timeout: 20000,
      });
      const text = r.data?.choices?.[0]?.message?.content || '';
      // Parse simple "Titulo: ...\nResumo: ..." if present; else split first line as title.
      let newTitle = it.title, newSummary = it.summary;
      const m1 = text.match(/t[ií]tulo\s*:\s*(.+)/i);
      const m2 = text.match(/resumo\s*:\s*([\s\S]+)/i);
      if(m1) newTitle = m1[1].trim();
      if(m2) newSummary = m2[1].trim();
      if(!m1 && !m2){
        const lines = text.split('\n').map(s=>s.trim()).filter(Boolean);
        if(lines[0]) newTitle = lines[0];
        if(lines[1]) newSummary = lines.slice(1).join(' ');
      }
      return { ...it, title: newTitle, summary: newSummary };
    }catch(e){
      return it; // falha não bloqueia
    }
  }
  return await Promise.all(items.map(it => limit(() => callAI(it))));
}

async function collect(){
  const items = [];
  for(const s of cfg.sources){
    try{
      if(s.type === 'rss'){
        const xml = await fetchText(s.url);
        items.push(...parseRSS(xml, s.section, s.label));
      } else {
        const html = await fetchText(s.url);
        items.push(...parseHTMLList(html, s.url, s.section, s.label));
      }
      await wait(400);
    }catch(e){}
  }
  const cutoff = Date.now() - 24*60*60*1000;
  const seen = new Set();
  const dedup = [];
  for(const it of items){
    const c = canon(it.url);
    if(seen.has(c)) continue; seen.add(c);
    if(it.published_at){
      const d = new Date(it.published_at);
      if(!Number.isNaN(d.getTime()) && d.getTime() < cutoff) continue;
    }
    dedup.push(it);
  }
  const buckets = { cartorios:[], corretores:[], ia:[], vagas:[] };
  for(const it of dedup) (buckets[it.section] = buckets[it.section] || []).push(it);
  for(const sec of Object.keys(buckets)){
    const limit = (cfg.limits?.[sec] ?? 6);
    buckets[sec] = buckets[sec].slice(0, limit);
    if(buckets[sec].length === 0){
      buckets[sec] = [{ title: "Você está atualizado, e não há nenhuma novidade.", url: "", summary: "", published_at: null, section: sec, source: "", image_url: null }];
    }
  }
  // Enriquecer com OG e depois chamar IA para PT-BR
  for(const sec of Object.keys(buckets)){
    await Promise.all(buckets[sec].map(async it => { if(it.url) it.image_url = await getOG(it.url); }));
    buckets[sec] = await enhancePTBR(buckets[sec]);
  }
  return buckets;
}

const buckets = await collect();
const sections = [
  { id:'cartorios', title:'Cartórios (RJ)', items:buckets.cartorios },
  { id:'corretores', title:'Corretores (CRECI/COFECI)', items:buckets.corretores },
  { id:'ia', title:'Inteligência Artificial', items:buckets.ia },
  { id:'vagas', title:'Vagas & Gigs (IA)', items:buckets.vagas },
];
const newsletter = { name:'Newsletter Veloso', edition_date: today, kicker: 'Seleção do dia', sections };
await fs.writeFile('feed.json', JSON.stringify({ newsletter }, null, 2), 'utf-8');
console.log('feed.json atualizado com tradução/edição PT-BR.');